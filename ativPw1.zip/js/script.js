function valida(){

  if (document.getElementById('nome').value==''){
    alert('Preencha o camp nome');
    document.getElementById('nome').focus();
    return false;
  }
  return true;

 



  
}